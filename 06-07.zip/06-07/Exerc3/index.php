<!DOCTYPE html> 
<head>
<title>Opçoes Conta</title>
</head>
<body>
<form method="GET" action="ContaIF.php">
Olá
<br>
Opçoes da Conta:
//1 = Sacar
//2 = Depositar
//3 = Transferir
<input type="text" name="acao" placeholder="Ação">
<br>
Valor:<input type="text" name="valor" placeholder="Valor">
<input type="submit" name="submit">
</form>
</body>
</html>
