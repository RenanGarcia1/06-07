<?php 
require_once 'ContaOB.php'; 
$C = new Conta(); 
$C->setSaldo(200); 
$acao=isset($_GET['acao'])?$_GET['acao']:null; 
if($acao=1){
$C->saque($_GET['valor']);
}
else if($acao=2){
$C->deposito($_GET['valor']);
}
else if($acao=3){
$C->transferencia($_GET['valor']);
}
echo "Olá, Agora você agora possui: R$".$C->getSaldo()." em sua conta bancária.";
?>