<?php 
class Conta{ 
private $saldo; 
public function getSaldo(){
return $this->saldo; 
}
public function setSaldo($saldo){
$this->saldo = $saldo; 
}
public function saque($valorD){ ;
$SaldoF = $this->getSaldo()-$valorD;
return $this->setSaldo($SaldoF);
}
public function deposito($valorD){  
$SaldoF = $this->getSaldo()+$valorD; 
return $this->setSaldo($SaldoF);
}
public function transferencia($valorD){ 
$SaldoF = $this->getSaldo()-$valorD;
return $this->setSaldo($SaldoF);
}
}
?>