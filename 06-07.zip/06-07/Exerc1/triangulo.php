<?php 
class triangulo{ 
public $base; 
public $altura; 
public $area; 
public function getAltura(){
return $this->altura; 
}
public function getBase(){
return $this->base; 
}  
public function getArea(){
return $this->area; 
}
public function setAltura($altura){
$this->altura = $altura; 
}
public function setBase($base){
$this->base = $base; 
}    
public function setArea($area){
$this->area = $area; 
}
public function Area(){
return ($this->getBase()*$this->getAltura()/2);
}
public function imprimir(){ 
echo "Base: ".$this->getAltura()."";
echo "</br>";
echo "Altura: ".$this->getBase()."";
echo "</br>";
echo "Area: ".$this->getArea()."";
}
}
?>