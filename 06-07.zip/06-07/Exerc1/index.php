<!DOCTYPE html> 
<head>
<title>Triangulo</title>
</head>
<body> 
<form class="" action="objeto.php" method="GET">
 Digite a base e a altura:
<p><input type="number" name="altura" placeholder="Altura"></p>
<p><input type="number" name="base" placeholder="Base"></p> 
<input type="submit" value="enviar">
</form>
</body>
</html>