<?php
require_once 'triangulo.php'; 
$triangulo1 = new Triangulo();
$triangulo1->setAltura($_GET['altura']);
$triangulo1->setBase($_GET['base']);
$triangulo1->setArea($triangulo1->Area());
$triangulo1->Area();
$triangulo1->imprimir();
    
?>