<?php

require_once 'media.php';

$nota1 = $_POST['nota1'];
$nota2 = $_POST['nota2'];
$nota3 = $_POST['nota3'];
$nota4 = $_POST['nota4'];

$media = new MediaF();
$media->setNota1($nota1);
$media->setNota2($nota2);
$media->setNota3($nota3);
$media->setNota4($nota4);

echo $media->calc($media->getNota1(), $media->getNota2(), $media->getNota3(),  $media->getNota4());
echo "<br> MB(para médias 9 e 10)
<br>B (7 e 8) 
<br>R (5 e 6)
<br>I (menos de 5).";

?>