<?php

class MediaF{

public $nota1;
public $nota2;
public $nota3;
public $nota4;
public $media;


public function getNota1(){
return $this->nota1;
}

public function getNota2(){
return $this->nota2;
}

public function getNota3(){
return $this->nota3;
}

public function getNota4(){
return $this->nota4;
}

public function setNota1($nota1){
$this->nota1 = $nota1;
return $this;
}

public function setNota2($nota2){
$this->nota2 = $nota2;
return $this;
}

public function setNota3($nota3){
$this->nota3 = $nota3;
return $this;
}

public function setNota4($nota4){
$this->nota4 = $nota4;

return $this;
}

public function calc($nota1, $nota2, $nota3, $nota4){
    $r = (($nota1+$nota2+$nota3+$nota4)/4);
    
    if($r  >= 9){
        $media = "MB";
    }
    else if($r  >= 7 && $r <= 8){
        $media = "B";
    }
    else if($r  >= 5 && $r <= 6){
        $media = "R";
    }
    elseif($r < 5){
        $media = "I";
    }
    return "Média Final: " . $r . " <br> Menção: " . $media;
}
}

?>