<!DOCTYPE html>

<head>
<title>Media</title>
</head>
<body>
<form  method="post" action="mediaop.php">
Digite as notas:
<br>
<input type="Number" id="nota1" name="nota1" placeholder="Nota 1"><br>
<input type="Number" id="nota2" name="nota2" placeholder="Nota 2"><br>
<input type="Number" id="nota3" name="nota3" placeholder="Nota 3"><br>
<input type="Number" id="nota4" name="nota4" placeholder="Nota 4"><br>
<input type="submit" value="enviar">
</form>
</body>
</html>